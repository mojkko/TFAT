import React from "react";

const TestFramework = () => {
  return (
    <div>
      <h1>TestFramework Page</h1>
      <p>
        Welcome to the TestFramework Page! This page is dedicated to the
        frameworks oooooooooo toyour testing process.
      </p>
      <p>You can use this page to oooooooooooooooo for your project.</p>
    </div>
  );
};

export default TestFramework;

import React from "react";

const Willkommen = () => {
  return (
    <div>
      <h1>Willkommen to TFAT!</h1>
      <p>
        This is the Welcome Page of our application. You can use this page to
        provide a brief introduction or any important information to your users.
      </p>
      <p>Feel free to explore the other pages using the navigation bar.</p>
    </div>
  );
};

export default Willkommen;

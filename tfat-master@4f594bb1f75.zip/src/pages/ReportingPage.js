import React from "react";

const Reporting = () => {
  return <h1>Reporting </h1>;
};

export default Reporting;

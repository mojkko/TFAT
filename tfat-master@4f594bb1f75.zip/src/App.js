import React from "react";
import "./App.css";
import Navbar from "./components/Navbar";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Willkommen from "./pages/WillkommenPage";
import ProjektKonfiguration from "./pages/ProjektKonfigurationPage";
import TestKonzeption from "./pages/TestKonzeptionPage";
import TestFramework from "./pages/TestFrameworkPage";
import Reporting from "./pages/ReportingPage";
import Summary from "./pages/SummaryPage";

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Willkommen />} />
          <Route index element={<Willkommen />} />
          <Route path="/ProjektKonfiguration" element={<ProjektKonfiguration/>}/>
          <Route path="/TestKonzeption" element={<TestKonzeption />} />
          <Route path="/TestFramework" element={<TestFramework />} />
          <Route path="/Reporting" element={<Reporting />} />
          <Route path="/Summary" element={<Summary />} />
      </Routes>
    </Router>
  );
}
export default App;
